A new version of Glitchium.exe i made
Credits to pankoza for this program opener (but System32), MBR wiper and text set i think
Previous version: Glitchium.exe (Old version)

Works only in Windows XP x86/x64 bits

If you run as an administrator, the MBR will instantly overwrite your computer.
Do not run this in your main PC! Use a virtual machine instead.

By the way, this malware is a slop. Cuz ai.